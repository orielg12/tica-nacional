import{i as e,t}from"./react-CYzKIDNi.js";import{r as n,t as r}from"./useStore-CKw4Zg0e.js";import{a as i,i as a,n as o,o as s,t as c}from"./index-BkafR866.js";import{t as l}from"./createLucideIcon-KWF6CZaM.js";import{t as u}from"./calendar-CP5jElE9.js";import{t as d}from"./file-text-B2jMG3sF.js";import{n as f,t as p}from"./menu-iQqOOALC.js";import{t as m}from"./plus-BxWGcpRE.js";import{t as h}from"./settings-3OwKCS0L.js";import{t as g}from"./sparkles-Df6N-gcv.js";import{t as _}from"./trophy-cK36msWX.js";import{t as v}from"./x-BQrJwOOf.js";var y=l(`bell`,[[`path`,{d:`M10.268 21a2 2 0 0 0 3.464 0`,key:`vwvbt9`}],[`path`,{d:`M3.262 15.326A1 1 0 0 0 4 17h16a1 1 0 0 0 .74-1.673C19.41 13.956 18 12.499 18 8A6 6 0 0 0 6 8c0 4.499-1.411 5.956-2.738 7.326`,key:`11g9vi`}]]),b=l(`building`,[[`path`,{d:`M12 10h.01`,key:`1nrarc`}],[`path`,{d:`M12 14h.01`,key:`1etili`}],[`path`,{d:`M12 6h.01`,key:`1vi96p`}],[`path`,{d:`M16 10h.01`,key:`1m94wz`}],[`path`,{d:`M16 14h.01`,key:`1gbofw`}],[`path`,{d:`M16 6h.01`,key:`1x0f13`}],[`path`,{d:`M8 10h.01`,key:`19clt8`}],[`path`,{d:`M8 14h.01`,key:`6423bh`}],[`path`,{d:`M8 6h.01`,key:`1dz90k`}],[`path`,{d:`M9 22v-3a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v3`,key:`cabbwy`}],[`rect`,{x:`4`,y:`2`,width:`16`,height:`20`,rx:`2`,key:`1uxh74`}]]),x=l(`chevron-right`,[[`path`,{d:`m9 18 6-6-6-6`,key:`mthhwq`}]]),S=l(`layout-dashboard`,[[`rect`,{width:`7`,height:`9`,x:`3`,y:`3`,rx:`1`,key:`10lvy0`}],[`rect`,{width:`7`,height:`5`,x:`14`,y:`3`,rx:`1`,key:`16une8`}],[`rect`,{width:`7`,height:`9`,x:`14`,y:`12`,rx:`1`,key:`1hutg5`}],[`rect`,{width:`7`,height:`5`,x:`3`,y:`16`,rx:`1`,key:`ldoo1y`}]]),C=l(`ticket`,[[`path`,{d:`M2 9a3 3 0 0 1 0 6v2a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-2a3 3 0 0 1 0-6V7a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2Z`,key:`qn84l0`}],[`path`,{d:`M13 5v2`,key:`dyzc3o`}],[`path`,{d:`M13 17v2`,key:`1ont0d`}],[`path`,{d:`M13 11v2`,key:`1wjjxi`}]]),w=l(`users`,[[`path`,{d:`M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2`,key:`1yyitq`}],[`path`,{d:`M16 3.128a4 4 0 0 1 0 7.744`,key:`16gr8j`}],[`path`,{d:`M22 21v-2a4 4 0 0 0-3-3.87`,key:`kshegd`}],[`circle`,{cx:`9`,cy:`7`,r:`4`,key:`nufk8`}]]),T=e(t(),1),E=c();function D(){let e=i(),t=s(),c=e.pathname,[l,D]=(0,T.useState)([]),[k,A]=(0,T.useState)(!1);(0,T.useEffect)(()=>{A(!1)},[e.pathname]),(0,T.useEffect)(()=>{let e=n.channel(`covers-alerts`).on(`postgres_changes`,{event:`INSERT`,schema:`public`,table:`covers`},e=>{let t=e.new;try{new Audio(`https://assets.mixkit.co/active_storage/sfx/2869/2869-preview.mp3`).play().catch(()=>{})}catch{}let n=`Exceso de $${parseFloat(t.excess_amount).toFixed(2)} enviado a respaldo.`,r=Date.now();D(e=>[...e,{id:r,message:n}]),setTimeout(()=>{D(e=>e.filter(e=>e.id!==r))},5e3)}).subscribe();return()=>{n.removeChannel(e)}},[]);let j=[{group:`PRINCIPAL`,items:[{to:`/admin`,label:`Dashboard`,icon:(0,E.jsx)(S,{size:18}),exact:!0},{to:`/admin/results`,label:`Resultados`,icon:(0,E.jsx)(_,{size:18})},{to:`/admin/forecasts`,label:`Pronósticos`,icon:(0,E.jsx)(g,{size:18})}]},{group:`GESTIÓN`,items:[{to:`/admin/tickets`,label:`Control de Tickets`,icon:(0,E.jsx)(C,{size:18})},{to:`/admin/users`,label:`Usuarios`,icon:(0,E.jsx)(w,{size:18})},{to:`/admin/risk`,label:`Bancas (Respaldo)`,icon:(0,E.jsx)(b,{size:18})},{to:`/admin/lotteries`,label:`Sorteos`,icon:(0,E.jsx)(u,{size:18})}]},{group:`FINANCIERO`,items:[{to:`/admin/reports`,label:`Reportes`,icon:(0,E.jsx)(d,{size:18})},{to:`/admin/manual-sale`,label:`Venta Manual`,icon:(0,E.jsx)(m,{size:18})}]},{group:`SISTEMA`,items:[{to:`/admin/settings`,label:`Configuración`,icon:(0,E.jsx)(h,{size:18})}]}],M=()=>(0,E.jsxs)(E.Fragment,{children:[(0,E.jsxs)(`div`,{style:{padding:`1.5rem`,borderBottom:`1px solid rgba(255,255,255,0.05)`,display:`flex`,alignItems:`center`,justifyContent:`space-between`},children:[(0,E.jsxs)(`div`,{children:[(0,E.jsx)(`h2`,{style:{fontSize:`1.1rem`,margin:0,color:`#3399ff`,fontWeight:800},children:`GO`}),(0,E.jsx)(`span`,{style:{fontSize:`0.7rem`,color:`#8b9bb4`},children:`Panel Administrativo v1.0`})]}),(0,E.jsx)(`button`,{onClick:()=>A(!1),style:{background:`transparent`,border:`none`,color:`#8b9bb4`,cursor:`pointer`,display:`none`},className:`sidebar-close-btn`,children:(0,E.jsx)(v,{size:20})})]}),(0,E.jsx)(`nav`,{style:{flex:1,padding:`1rem 0`,overflowY:`auto`},children:j.map(e=>(0,E.jsxs)(`div`,{children:[(0,E.jsx)(`div`,{style:{padding:`0 1.5rem`,fontSize:`0.65rem`,color:`#5b6b84`,fontWeight:`bold`,letterSpacing:`1px`,margin:`1rem 0 0.5rem 0`},children:e.group}),e.items.map(e=>{let t=(e.exact,c===e.to);return(0,E.jsxs)(o,{to:e.to,className:`admin-nav-link`,style:O(t),children:[e.icon,(0,E.jsx)(`span`,{style:{flex:1},children:e.label}),(0,E.jsx)(x,{size:14,style:{opacity:.4}})]},e.to)})]},e.group))}),(0,E.jsxs)(`div`,{style:{padding:`1rem 1.5rem`,borderTop:`1px solid rgba(255,255,255,0.05)`,display:`flex`,alignItems:`center`,justifyContent:`space-between`},children:[(0,E.jsxs)(`div`,{style:{display:`flex`,alignItems:`center`,gap:`0.8rem`},children:[(0,E.jsx)(`div`,{style:{width:`32px`,height:`32px`,borderRadius:`50%`,backgroundColor:`#3399ff`,display:`flex`,alignItems:`center`,justifyContent:`center`,fontWeight:`bold`},children:`A`}),(0,E.jsxs)(`div`,{children:[(0,E.jsx)(`div`,{style:{fontSize:`0.85rem`,fontWeight:`bold`},children:`Administrador`}),(0,E.jsx)(`div`,{style:{fontSize:`0.7rem`,color:`#8b9bb4`},children:`Activo`})]})]}),(0,E.jsx)(`button`,{onClick:()=>{r.getState().logout(),t(`/login`,{replace:!0})},style:{background:`transparent`,border:`none`,color:`#dc3545`,cursor:`pointer`,padding:`0.5rem`},children:(0,E.jsx)(f,{size:18})})]})]});return(0,E.jsxs)(E.Fragment,{children:[(0,E.jsx)(`style`,{children:`
        @keyframes slideIn {
          from { transform: translateX(100%); opacity: 0; }
          to { transform: translateX(0); opacity: 1; }
        }
        @keyframes slideInLeft {
          from { transform: translateX(-100%); }
          to { transform: translateX(0); }
        }
        .admin-sidebar-mobile {
          animation: slideInLeft 0.25s ease-out;
        }
        .admin-layout-root {
          height: 100vh;
          height: 100dvh;
        }
        @media (max-width: 768px) {
          .admin-sidebar-desktop { display: none !important; }
          .admin-topbar { display: flex !important; }
          .sidebar-close-btn { display: flex !important; }
        }
        @media (min-width: 769px) {
          .admin-sidebar-mobile-overlay { display: none !important; }
          .admin-topbar { display: none !important; }
        }
        .admin-nav-link:hover {
          background-color: rgba(255,255,255,0.05);
          color: #fff;
        }

        /* ── RESPONSIVE GLOBAL PARA TODAS LAS PÁGINAS DEL ADMIN ── */
        @media (max-width: 768px) {

          /* Reducir padding general de páginas */
          main > div[style*="padding: '2rem'"],
          main > div[style*='padding: "2rem"'],
          main > div {
            padding: 0.75rem !important;
            padding-bottom: 3.5rem !important;
          }

          /* Grids de tarjetas: forzar columna única o 2 cols máximo */
          main div[style*="grid-template-columns"] {
            grid-template-columns: 1fr !important;
          }

          /* Headers de página: apilar verticalmente */
          main div[style*="justifyContent: 'space-between'"],
          main div[style*='justifyContent: "space-between"'] {
            flex-direction: column !important;
            align-items: flex-start !important;
            gap: 0.75rem !important;
          }

          /* Botones de acción en headers: ocupar ancho completo */
          main div[style*="justifyContent: 'space-between'"] > div[style*="display: 'flex'"],
          main div[style*='justifyContent: "space-between"'] > div {
            width: 100% !important;
            flex-wrap: wrap !important;
          }

          /* Filtro de fecha: apilar en columna */
          main div[style*="alignItems: 'flex-end'"] {
            flex-direction: column !important;
            align-items: stretch !important;
          }

          /* Tablas: scroll horizontal */
          main table {
            display: block !important;
            overflow-x: auto !important;
            -webkit-overflow-scrolling: touch !important;
            white-space: nowrap !important;
          }

          /* Tabla de desglose de cajero - reducir padding celdas */
          main th, main td {
            padding: 0.6rem 0.75rem !important;
            font-size: 0.8rem !important;
          }

          /* Bloques financieros de modalidad: apilar */
          main div[style*="minmax(250px"] {
            grid-template-columns: 1fr !important;
          }
          main div[style*="minmax(300px"] {
            grid-template-columns: 1fr !important;
          }

          /* Texto largo: permitir wrap */
          main h2, main h3, main h4 {
            font-size: 0.95rem !important;
            white-space: normal !important;
          }
          main span[style*="fontSize: '0.85rem'"] {
            display: none;
          }

          /* Tarjetas de resumen: ajustar tamaño de cifras */
          main h3[style*="1.5rem"], main h3[style*="1.8rem"], main h3[style*="2rem"] {
            font-size: 1.3rem !important;
          }

          /* Panel expandible del cajero: una sola columna */
          main div[style*="gridTemplateColumns: '1fr 1fr'"] {
            grid-template-columns: 1fr !important;
          }

          /* Fila de banca 0.20/0.25: apilar en lugar de side-by-side */
          main div[style*="display: 'flex'"][style*="gap: '1rem'"] > div[style*="flex: 1"] {
            min-width: 0 !important;
          }

          /* Inputs de fecha: ancho completo */
          main input[type="date"],
          main select {
            width: 100% !important;
            font-size: 0.9rem !important;
          }

          /* Botones: no rebasar pantalla */
          main button {
            font-size: 0.8rem !important;
          }

          /* Dashboard cards wrap */
          .admin-card-grid {
            grid-template-columns: repeat(2, 1fr) !important;
          }
        }

        /* Pantallas muy pequeñas (< 400px) */
        @media (max-width: 400px) {
          main > div {
            padding: 0.5rem !important;
          }
          main th, main td {
            padding: 0.4rem 0.5rem !important;
            font-size: 0.72rem !important;
          }
        }
      `}),(0,E.jsxs)(`div`,{className:`admin-layout-root`,style:{display:`flex`,width:`100vw`,backgroundColor:`#f0f4f8`,color:`#333`,overflow:`hidden`},children:[(0,E.jsx)(`aside`,{className:`admin-sidebar-desktop`,style:{width:`260px`,minWidth:`260px`,backgroundColor:`#17233D`,color:`#fff`,display:`flex`,flexDirection:`column`,boxShadow:`2px 0 10px rgba(0,0,0,0.1)`,zIndex:10},children:(0,E.jsx)(M,{})}),k&&(0,E.jsxs)(`div`,{className:`admin-sidebar-mobile-overlay`,style:{position:`fixed`,inset:0,zIndex:200,display:`flex`},children:[(0,E.jsx)(`div`,{onClick:()=>A(!1),style:{position:`absolute`,inset:0,backgroundColor:`rgba(0,0,0,0.6)`,backdropFilter:`blur(2px)`}}),(0,E.jsx)(`aside`,{className:`admin-sidebar-mobile`,style:{position:`relative`,width:`280px`,backgroundColor:`#17233D`,color:`#fff`,display:`flex`,flexDirection:`column`,zIndex:1,boxShadow:`4px 0 20px rgba(0,0,0,0.4)`},children:(0,E.jsx)(M,{})})]}),(0,E.jsxs)(`div`,{style:{flex:1,display:`flex`,flexDirection:`column`,overflow:`hidden`},children:[(0,E.jsxs)(`header`,{className:`admin-topbar`,style:{display:`none`,alignItems:`center`,justifyContent:`space-between`,padding:`0.75rem 1rem`,backgroundColor:`#17233D`,color:`#fff`,boxShadow:`0 2px 8px rgba(0,0,0,0.2)`,zIndex:50,flexShrink:0},children:[(0,E.jsx)(`button`,{onClick:()=>A(!0),style:{background:`transparent`,border:`none`,color:`#fff`,cursor:`pointer`,padding:`0.4rem`},children:(0,E.jsx)(p,{size:24})}),(0,E.jsx)(`h2`,{style:{margin:0,fontSize:`1rem`,color:`#3399ff`,fontWeight:800},children:`GO`}),(0,E.jsx)(`button`,{onClick:()=>{r.getState().logout(),t(`/login`,{replace:!0})},style:{background:`transparent`,border:`none`,color:`#dc3545`,cursor:`pointer`,padding:`0.4rem`},children:(0,E.jsx)(f,{size:20})})]}),(0,E.jsxs)(`main`,{style:{flex:1,overflowY:`auto`,display:`flex`,flexDirection:`column`,position:`relative`},children:[(0,E.jsx)(`div`,{style:{position:`fixed`,top:`70px`,right:`20px`,zIndex:9999,display:`flex`,flexDirection:`column`,gap:`10px`},children:l.map(e=>(0,E.jsxs)(`div`,{style:{backgroundColor:`#ef4444`,color:`white`,padding:`12px 20px`,borderRadius:`8px`,boxShadow:`0 4px 12px rgba(239, 68, 68, 0.3)`,display:`flex`,alignItems:`center`,gap:`10px`,fontWeight:`bold`,animation:`slideIn 0.3s ease-out`},children:[(0,E.jsx)(y,{size:20}),e.message]},e.id))}),(0,E.jsx)(a,{})]})]})]})]})}function O(e){return{display:`flex`,alignItems:`center`,gap:`0.8rem`,padding:`0.7rem 1.5rem`,color:e?`#fff`:`#8b9bb4`,backgroundColor:e?`rgba(255,255,255,0.05)`:`transparent`,borderLeft:e?`3px solid #3399ff`:`3px solid transparent`,textDecoration:`none`,fontSize:`0.85rem`,transition:`all 0.2s`,fontWeight:e?`600`:`normal`}}export{D as default};